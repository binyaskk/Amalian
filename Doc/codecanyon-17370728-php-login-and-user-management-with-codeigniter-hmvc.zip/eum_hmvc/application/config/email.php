<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    $config['protocol'] = 'smtp'; 
	$config['smtp_host'] = 'smtp_host';  //e.g: ssl://smtp.googlemail.com
	$config['smtp_port'] = 465;  //port number
	$config['smtp_user'] = 'smtp_user'; //e.g: youmail@gmail.com
	$config['smtp_pass'] = 'smtp_pass'; //e.g: password123
	$config['mailtype'] = 'html';
	$config['charset'] = 'iso-8859-1';