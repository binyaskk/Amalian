<?php
$lang['module_home']='Home';
  
$lang['module_users']='Users';
$lang['module_users_desc']='Add, Update, Delete, and Search Users';
 
$lang['module_reports']='Reports';
$lang['module_reports_desc']='View and generate reports';
 

$lang['module_config']='App Config';
$lang['module_config_desc']='Change the app\'s configuration';
 

$lang['module_dashboards']='Dashboard';
$lang['module_dashboards_desc']='View Dashboard';

$lang['module_profiles']='My Profile';
$lang['module_profiles_desc']='Add, Update and Delete Profiles';

$lang['module_user_reports']='User Report ';
$lang['module_user_reports_desc']='View Users';

$lang['module_trashes']='Trash ';
$lang['module_trashes_desc']='View Deleted Users';

