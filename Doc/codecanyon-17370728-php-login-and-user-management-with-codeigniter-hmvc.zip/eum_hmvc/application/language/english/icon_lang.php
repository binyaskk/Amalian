<?php
$lang['icon_view']="<i class='fa fa-eye'></i>";
$lang['icon_user_view']="<i class='fa fa-user' ></i>";
$lang['icon_edit']="<i class='fa fa-pencil-square-o'></i>";
$lang['icon_image']="<i class='fa fa-file-image-o'></i>";
$lang['icon_delete']="<i class='fa fa-trash-o'></i>";
$lang['icon_undo']="<i class='fa fa-undo'></i>";
$lang['icon_lock']="<i class='fa fa-user-secret' ></i>";
$lang['icon_pay']="<i class='fa fa-inr'></i>";
$lang['icon_sales']="<i class='fa fa-shopping-cart'></i>";
$lang['icon_service']="<i class='fa fa-wrench'></i>";
$lang['icon_date']="<img align='middle' style='width:25px;padding:2px' src='".base_url()."/imagesNew/icons/calendar.png'/>";
$lang['icon_pay_small']="<i class='fa fa-inr'></i>";

