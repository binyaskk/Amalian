<?php
$lang['main_module_1']='User';
$lang['main_module_1_icon']='fa fa-building-o';
$lang['main_module_2']='App Config';
$lang['main_module_2_icon']='fa fa-cogs';
$lang['main_module_3']='Reports';
$lang['main_module_3_icon']='fa fa-info';
$lang['main_module_4']='Dashboard';
$lang['main_module_4_icon']='fa fa-tachometer';
