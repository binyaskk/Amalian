<?php
$lang['dashboard_total_users']='Total Users';
$lang['dashboard_active_users']='Active Users';
$lang['dashboard_deactivated_users']='Deactivated Users ';
$lang['dashboard_deleted_users']='Deleted Users';
$lang['dashboard_more_info']='More info ';
