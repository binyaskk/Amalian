<?php 
class EUM_Controller extends MX_Controller
{
	function __construct()
	{
		parent::__construct();
	}
}