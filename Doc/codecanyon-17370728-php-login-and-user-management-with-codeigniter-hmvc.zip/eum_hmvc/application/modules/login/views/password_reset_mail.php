<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

      <!-- Main content -->
      <div class="row">
         <div class="col-md-12">
            <div class="box box-info login_form" >
               <div class="box-header with-border">
                   
               </div>
               <!-- /.box-header -->
               <!-- form start -->
           
               <div class="box-body">
                  <h6  class="text-center" id="<?php echo $success; ?>" > <?php echo $message;  ?>  	</h6>
				   
				  
               </div>
               <!-- /.box-body -->
               <div class="box-footer">
 
               
                   
               </div>
			  
              
            </div>
         </div>
      </div>
