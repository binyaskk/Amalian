<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

      <div class="row">
         <div class="col-md-12">
            <div class="box box-info login_form" >
               <div class="box-header with-border">
                   
               </div>
               <!-- /.box-header -->
               <!-- form start -->
           
               <div class="box-body">
                   <h4 class="box-title text-center" ><?php  echo $this->lang->line('common_404')  ?> </h4> 
            
                  <h6  class="text-center"> <?php echo $this->lang->line('common_404_message')  ?>   	</h6>
				   
				  
               </div>
               <!-- /.box-body -->
               <div class="box-footer">
 
               
                   
               </div>
			  
              
            </div>
         </div>
      </div>
    