      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
          <?php echo $this->lang->line('common_welcome'); ?>
    
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-lg-12">
              <!-- small box -->
         
            </div><!-- ./col -->
		 
           <h1 class="center home_header"   ><?php  echo  $login_info->first_name." ".$login_info->last_name; ?></h1>
          </div><!-- /.row -->
         
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->