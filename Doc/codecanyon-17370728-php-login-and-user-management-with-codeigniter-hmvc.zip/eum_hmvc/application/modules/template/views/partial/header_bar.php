<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>   <!-- Main Header -->
      <header class="main-header">

        <!-- Header Text -->
        <a href="<?php echo site_url()."/login"; ?>" class="logo"><b><?php  echo $this->config->item('company'); ?></b></a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
          </a>
          <!-- Navbar Right Logout Menu -->
          <div class="navbar-custom-menu">
             
          </div>
        </nav> 
      </header>
