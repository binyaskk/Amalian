 <link rel="stylesheet" href="<?php echo base_url();?>assets/css/qunit.css">
 <link rel="stylesheet" href="<?php echo base_url();?>assets/css/cropper.css">
 <link rel="stylesheet" href="<?php echo base_url();?>assets/css/main.css">
 <!-- <script src="<?php echo base_url();?>assets/js/qunit.js"></script> -->
 <script src="<?php echo base_url();?>assets/js/cropper.js"></script>
