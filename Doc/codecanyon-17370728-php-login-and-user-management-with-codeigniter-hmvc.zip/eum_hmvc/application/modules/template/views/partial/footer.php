<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> <!-- Main Footer -->
      <footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
         ©<?php echo $this->config->item('company'); ?>
        </div>
     
      </footer>