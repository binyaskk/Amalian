<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
 <!-- Message box -->
<script src="<?php echo base_url();?>assets/js/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>assets/js/jquery.alerts.js" type="text/javascript"></script>
<link href="<?php echo base_url();?>assets/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />

<script src="<?php echo base_url();?>assets/js/jquery-1.2.6.min.js" ></script> 
<script src="<?php echo base_url();?>assets/js/jquery-1.11.2.min.js"  ></script>
<script src="<?php echo base_url();?>assets/js/jquery-migrate-1.2.1.min.js"  ></script>
<!-- Form validation -->
<script src="<?php echo base_url();?>assets/js/jquery.validate.min1.7.js" ></script>